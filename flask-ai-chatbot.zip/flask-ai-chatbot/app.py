import os
from flask import Flask, render_template, request, jsonify
from openai import OpenAI
from dotenv import load_dotenv


# Carica le variabili dal file .env
load_dotenv()


app = Flask(__name__)


# Inizializza il client API (es. OpenAI o Groq)
client = OpenAI(api_key=os.getenv("OPENAI_API_KEY"))


# Cronologia della conversazione (mantiene il contesto dei messaggi)
conversation_history = [
    {"role": "system", "content": "Sei un assistente AI esperto in ingegneria e programmazione."}
]


@app.route("/")
def index():
    # Renderizza la pagina HTML della chat
    return render_template("index.html")


@app.route("/chat", methods=["POST"])
def chat():
    data = request.get_json()
    user_message = data.get("message", "")
    
    if not user_message:
        return jsonify({"error": "Messaggio vuoto"}), 400


    # Aggiunge il messaggio dell'utente alla cronologia
    conversation_history.append({"role": "user", "content": user_message})


    try:
        # Chiamata al modello linguistico (es. GPT-4o-mini o Llama)
        response = client.chat.completions.create(
            model="gpt-4o-mini",
            messages=conversation_history,
            temperature=0.7
        )
        
        bot_reply = response.choices[0].message.content


        # Aggiunge la risposta del bot alla cronologia
        conversation_history.append({"role": "assistant", "content": bot_reply})


        return jsonify({"reply": bot_reply})


    except Exception as e:
        return jsonify({"error": str(e)}), 500


if __name__ == "__main__":
    app.run(debug=True, port=5000)

